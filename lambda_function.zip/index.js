const { ChatOpenAI } = require('@langchain/openai');
const { HumanMessage, SystemMessage } = require('@langchain/core/messages');

exports.handler = async (event) => {
    const apiKey = process.env.OPENAI_API_KEY;
    const model = new ChatOpenAI({
        apiKey,
        modelName: 'gpt-4o',
    });

    const messages = [
        new SystemMessage("Translate the following from English into Italian"),
        new HumanMessage("hi!"),
    ];

    try {
        const response = await model.invoke(messages);
        return {
            statusCode: 200,
            body: JSON.stringify({ response: response.text }),
        };
    } catch (error) {
        console.error('Error generating response:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Error generating response' }),
        };
    }
};
